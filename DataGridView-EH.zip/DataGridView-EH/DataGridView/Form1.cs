﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridView
{
    public partial class Form1 : Form
         
    {
        //db30 is the database file
        
        SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\muham\source\repos\DataGridView\db\db30.mdf;Integrated Security=True;Connect Timeout=30");
        int CId = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                if (btnsave.Text == "Save")
                {
                    SqlCommand sqlCmd = new SqlCommand("AddorEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@mode", "Add");
                    sqlCmd.Parameters.AddWithValue("@CId", 0);
                    sqlCmd.Parameters.AddWithValue("@Id", txtid.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@name", txtname.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@address", txtaddress.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Saved successfully");
                }
                else
                {
                    // AddorEdit is the SharedProceduredata of databse in which queries are written. @values are those that are used as initialization for the table elements.
                    SqlCommand sqlCmd = new SqlCommand("AddOrEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@mode", "Edit");
                    sqlCmd.Parameters.AddWithValue("@CId", CId);
                    sqlCmd.Parameters.AddWithValue("@Id", txtid.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@name", txtname.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@address", txtaddress.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Updated successfully");
                }
                Reset();
                datafill();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {

            try
            {
                datafill();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dataGridViewSQL_DoubleClick(object sender, EventArgs e)
        {
             if (dataGridViewSQL.CurrentRow.Index != -1)
              {
                 CId = Convert.ToInt32(dataGridViewSQL.CurrentRow.Cells[0].Value.ToString());
                  txtid.Text = dataGridViewSQL.CurrentRow.Cells[1].Value.ToString();
                  txtname.Text = dataGridViewSQL.CurrentRow.Cells[2].Value.ToString();
                  txtaddress.Text = dataGridViewSQL.CurrentRow.Cells[3].Value.ToString();
                  btnsave.Text = "Update";
                  btnremove.Enabled = true;

              }
        }
        void Reset()
        {
            txtid.Text = txtname.Text = txtaddress.Text = "";
            btnsave.Text = "Save";
            CId = 0;
            btnremove.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            DataTable tb = new DataTable();
            DataRow dr = tb.NewRow();
            tb.Rows.Add(dr);



        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("Deletion", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@CId", CId);
                sqlCmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully");
                Reset();
                datafill();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }
        void datafill()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("ViewOrSearch", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@name", txtBoxSQL.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dataGridViewSQL.DataSource = dtbl;
            dataGridViewSQL.Columns[0].Visible = false;
            sqlCon.Close();
        }

        private void txtBoxSQL_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
    

